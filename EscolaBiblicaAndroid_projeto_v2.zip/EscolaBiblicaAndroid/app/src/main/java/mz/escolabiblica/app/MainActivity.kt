package mz.escolabiblica.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

private val Navy = Color(0xFF172B45)
private val Gold = Color(0xFFD9B86C)
private val Paper = Color(0xFFF7F5F0)

data class SavedSermon(
    val title: String,
    val bibleText: String,
    val theme: String,
    val introduction: String,
    val points: String,
    val conclusion: String
)

private fun loadSermons(context: android.content.Context): List<SavedSermon> {
    val raw = context.getSharedPreferences("escola_biblica", android.content.Context.MODE_PRIVATE)
        .getString("sermons", "[]") ?: "[]"
    return try {
        val array = JSONArray(raw)
        (0 until array.length()).map { i ->
            val item = array.getJSONObject(i)
            SavedSermon(
                item.optString("title"), item.optString("bibleText"),
                item.optString("theme"), item.optString("introduction"),
                item.optString("points"), item.optString("conclusion")
            )
        }
    } catch (_: Exception) { emptyList() }
}

private fun persistSermons(context: android.content.Context, sermons: List<SavedSermon>) {
    val array = JSONArray()
    sermons.forEach { sermon ->
        array.put(JSONObject().apply {
            put("title", sermon.title)
            put("bibleText", sermon.bibleText)
            put("theme", sermon.theme)
            put("introduction", sermon.introduction)
            put("points", sermon.points)
            put("conclusion", sermon.conclusion)
        })
    }
    context.getSharedPreferences("escola_biblica", android.content.Context.MODE_PRIVATE)
        .edit().putString("sermons", array.toString()).apply()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EscolaBiblicaApp() }
    }
}

@Composable
fun EscolaBiblicaApp() {
    var page by remember { mutableStateOf("Início") }
    var selectedCourse by remember { mutableStateOf("") }
    var sermonTitle by remember { mutableStateOf("") }
    var sermonText by remember { mutableStateOf("") }
    var sermonTheme by remember { mutableStateOf("") }
    var sermonIntro by remember { mutableStateOf("") }
    var sermonPoints by remember { mutableStateOf("") }
    var sermonConclusion by remember { mutableStateOf("") }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Navy, secondary = Gold, background = Paper,
            surface = Color.White, onPrimary = Color.White
        )
    ) {
        Scaffold(
            containerColor = Paper,
            topBar = {
                Column(Modifier.fillMaxWidth().background(Navy).padding(horizontal = 18.dp, vertical = 16.dp)) {
                    Text("ESCOLA BÍBLICA", color = Gold, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text(page, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    val items = listOf("Início", "Estudos", "Pregações", "Cursos", "Biblioteca")
                    val icons = listOf(Icons.Default.Home, Icons.Default.MenuBook, Icons.Default.Mic, Icons.Default.School, Icons.Default.Bookmark)
                    items.forEachIndexed { index, item ->
                        NavigationBarItem(
                            selected = page == item,
                            onClick = { page = item },
                            icon = { Icon(icons[index], contentDescription = item) },
                            label = { Text(item, fontSize = 10.sp) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                when (page) {
                    "Início" -> {
                        Card(colors = CardDefaults.cardColors(containerColor = Navy), shape = RoundedCornerShape(22.dp)) {
                            Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("Conhecimento • Fé • Serviço", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text("Cresça no conhecimento da Palavra de Deus.", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                                Text("Estude, prepare pregações e fortaleça o seu ministério.", color = Color.White.copy(alpha = .85f), fontSize = 16.sp)
                            }
                        }
                        Text("Acesso rápido", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Navy)
                        MenuCard("Estudos bíblicos", "Explore temas, personagens e doutrinas", Icons.Default.MenuBook) { page = "Estudos" }
                        MenuCard("Preparar uma pregação", "Organize o seu sermão passo a passo", Icons.Default.Mic) { page = "Pregações" }
                        MenuCard("Cursos de formação", "Aprenda com lições organizadas", Icons.Default.School) { page = "Cursos" }
                        MenuCard("Devocional diário", "Uma reflexão para o seu dia", Icons.Default.WbSunny) { page = "Devocional" }
                    }
                    "Estudos" -> {
                        SectionIntro("Estudos bíblicos", "Conteúdos introdutórios para começar a estudar.")
                        listOf(
                            "A vida de Jesus" to "Conheça os principais momentos do ministério de Cristo. Leia Mateus 4:17 e Marcos 1:14–15.",
                            "O apóstolo Paulo" to "Estude a conversão, as viagens missionárias e as cartas de Paulo. Leia Actos 9:1–19.",
                            "As parábolas de Jesus" to "Descubra como Jesus ensinava por meio de histórias. Leia Lucas 15.",
                            "O fruto do Espírito" to "Compreenda o carácter cristão descrito em Gálatas 5:22–23."
                        ).forEach { (title, body) -> InfoCard(title, body) }
                    }
                    "Pregações" -> {
                        SectionIntro("Preparação de pregações", "Preencha os campos para estruturar uma mensagem.")
                        OutlinedTextField(sermonTitle, { sermonTitle = it }, label = { Text("Título da pregação") }, modifier = Modifier.fillMaxWidth(), textStyle = LocalTextStyle.current.copy(fontSize = 18.sp))
                        OutlinedTextField(sermonText, { sermonText = it }, label = { Text("Texto bíblico (ex.: João 15:1–8)") }, modifier = Modifier.fillMaxWidth(), textStyle = LocalTextStyle.current.copy(fontSize = 18.sp))
                        OutlinedTextField(sermonTheme, { sermonTheme = it }, label = { Text("Tema / ideia central") }, modifier = Modifier.fillMaxWidth(), textStyle = LocalTextStyle.current.copy(fontSize = 18.sp))
                        OutlinedTextField(sermonIntro, { sermonIntro = it }, label = { Text("Introdução") }, modifier = Modifier.fillMaxWidth(), minLines = 2, textStyle = LocalTextStyle.current.copy(fontSize = 18.sp))
                        OutlinedTextField(sermonPoints, { sermonPoints = it }, label = { Text("Pontos principais") }, modifier = Modifier.fillMaxWidth(), minLines = 3, textStyle = LocalTextStyle.current.copy(fontSize = 18.sp))
                        OutlinedTextField(sermonConclusion, { sermonConclusion = it }, label = { Text("Conclusão e aplicação") }, modifier = Modifier.fillMaxWidth(), minLines = 2, textStyle = LocalTextStyle.current.copy(fontSize = 18.sp))
                        Button(
                            onClick = {
                                if (sermonTitle.isNotBlank() && sermonText.isNotBlank()) {
                                    val item = SavedSermon(sermonTitle, sermonText, sermonTheme, sermonIntro, sermonPoints, sermonConclusion)
                                    savedSermons = listOf(item) + savedSermons
                                    persistSermons(context, savedSermons)
                                    saveMessage = "Pregação guardada na biblioteca deste telemóvel."
                                    sermonTitle = ""; sermonText = ""; sermonTheme = ""
                                    sermonIntro = ""; sermonPoints = ""; sermonConclusion = ""
                                } else {
                                    saveMessage = "Preencha pelo menos o título e o texto bíblico."
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Navy)
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Guardar pregação", fontSize = 17.sp)
                        }
                        if (saveMessage.isNotBlank()) {
                            Text(saveMessage, color = Navy, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Text("As pregações guardadas ficam armazenadas neste telemóvel.", color = Color.DarkGray, fontSize = 13.sp)
                    }
                    "Cursos" -> {
                        SectionIntro("Cursos de formação", "Escolha uma disciplina para conhecer os seus módulos.")
                        val courses = listOf(
                            "Homilética" to "Preparação, estrutura e comunicação da pregação bíblica.",
                            "Hermenêutica" to "Princípios para interpretar as Escrituras com atenção ao contexto.",
                            "Teologia" to "Estudo organizado das doutrinas fundamentais da fé cristã.",
                            "Liderança cristã" to "Carácter, serviço, responsabilidade e cuidado pastoral.",
                            "Evangelismo" to "Fundamentos e prática de anunciar o Evangelho."
                        )
                        courses.forEach { (name, desc) ->
                            MenuCard(name, desc, Icons.Default.School) { selectedCourse = name }
                        }
                        if (selectedCourse.isNotBlank()) {
                            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFECE7DA))) {
                                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                                    Text(selectedCourse, fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Navy)
                                    Text("Módulo 1 — Introdução e fundamentos", fontWeight = FontWeight.SemiBold)
                                    Text(courses.first { it.first == selectedCourse }.second)
                                    if (selectedCourse == "Homilética") {
                                        Text("Lição 1 — O que é pregação bíblica?", fontWeight = FontWeight.Bold)
                                        Text("A pregação bíblica comunica fielmente a mensagem das Escrituras, explicando o texto e mostrando a sua relevância para a vida.")
                                        Text("Lição 2 — O lugar das Escrituras", fontWeight = FontWeight.Bold)
                                        Text("A mensagem deve nascer do texto bíblico. Leia o contexto antes e depois da passagem e identifique a ideia principal.")
                                        Text("Lição 3 — Estrutura básica do sermão", fontWeight = FontWeight.Bold)
                                        Text("Uma estrutura inicial inclui introdução, explicação do texto, pontos principais, aplicações e conclusão.")
                                        Text("Lição 4 — Aplicação e comunicação", fontWeight = FontWeight.Bold)
                                        Text("A aplicação deve ser clara, coerente com o texto e dirigida à vida real dos ouvintes.")
                                        Text("Exercício: leia Marcos 4:35–41. Escreva o tema central, dois pontos de explicação e uma aplicação.")
                                    } else {
                                        Text("Próximo passo: desenvolver as lições, referências bíblicas e exercícios desta disciplina.", fontSize = 14.sp)
                                    }
                                }
                            }
                        }
                    }
                    "Biblioteca" -> {
                        SectionIntro("Minha biblioteca", "As suas pregações guardadas neste telemóvel.")
                        if (savedSermons.isEmpty()) {
                            InfoCard("Ainda não há pregações guardadas", "Abra a área Pregações, preencha o título e o texto bíblico e toque em Guardar pregação.")
                        } else {
                            savedSermons.forEachIndexed { index, sermon ->
                                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
                                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                        Text(sermon.title, color = Navy, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                                        Text(sermon.bibleText, color = Color.DarkGray, fontSize = 15.sp)
                                        if (sermon.theme.isNotBlank()) Text("Tema: ${sermon.theme}", fontSize = 15.sp)
                                        if (sermon.points.isNotBlank()) Text("Pontos: ${sermon.points}", fontSize = 14.sp)
                                        TextButton(onClick = {
                                            savedSermons = savedSermons.filterIndexed { i, _ -> i != index }
                                            persistSermons(context, savedSermons)
                                        }) {
                                            Icon(Icons.Default.Delete, contentDescription = null)
                                            Spacer(Modifier.width(5.dp))
                                            Text("Apagar")
                                        }
                                    }
                                }
                            }
                        }
                        InfoCard("Privacidade", "As pregações são guardadas localmente neste dispositivo. Esta versão ainda não sincroniza os dados com a internet.")
                    }
                    "Devocional" -> {
                        SectionIntro("Devocional diário", "Uma pausa para ler, meditar e orar.")
                        InfoCard("Versículo para reflexão", "“Lâmpada para os meus pés é a tua palavra e luz para o meu caminho.” — Salmo 119:105")
                        InfoCard("Reflexão", "A Palavra de Deus orienta as nossas decisões. Reserve tempo para ler o contexto do texto, meditar e colocar o ensinamento em prática.")
                        InfoCard("Oração", "Senhor, dá-me entendimento para conhecer a tua Palavra e sabedoria para a viver. Ámen.")
                    }
                    else -> SectionIntro(page, "Conteúdo em preparação.")
                }
            }
        }
    }
}

@Composable
fun SectionIntro(title: String, subtitle: String) {
    Text(title, color = Navy, fontSize = 23.sp, fontWeight = FontWeight.Bold)
    Text(subtitle, color = Color.DarkGray, fontSize = 16.sp)
}

@Composable
fun InfoCard(title: String, body: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(17.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text(title, color = Navy, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Text(body, color = Color(0xFF343434), fontSize = 16.sp, lineHeight = 24.sp)
        }
    }
}

@Composable
fun MenuCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Box(Modifier.size(48.dp).background(Navy, RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = null, tint = Gold)
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, color = Navy, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(subtitle, color = Color.DarkGray, fontSize = 14.sp, lineHeight = 19.sp)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Navy)
        }
    }
}
