# Escola Bíblica — projecto Android inicial

Este é um projecto-fonte Android nativo, escrito em Kotlin com Jetpack Compose.

## Incluído nesta versão inicial
- Navegação por Início, Estudos, Pregações, Cursos e Biblioteca.
- Área de devocional diário.
- Conteúdo introdutório em português.
- Formulário para estruturar e guardar pregações no próprio telemóvel (armazenamento local simples).
- Biblioteca que lista e permite apagar pregações guardadas.
- Primeiras quatro lições introdutórias do curso de Homilética.
- Cursos listados: Homilética, Hermenêutica, Teologia, Liderança cristã e Evangelismo.
- Interface com letras relativamente grandes e contraste azul-marinho/dourado.
- Estrutura offline-first: o conteúdo demonstrativo está incluído no aplicativo e não exige internet.

## Ainda não incluído
- Sincronização online e cópias de segurança.
- Conta de utilizador e sincronização entre dispositivos.
- Catálogo completo de aulas e avaliações.
- Bíblia integral/licenciada.
- APK compilado e assinado.

## Como abrir e gerar o APK
1. Instale o Android Studio num computador.
2. Extraia esta pasta.
3. No Android Studio, escolha **Open** e seleccione a pasta `EscolaBiblicaAndroid`.
4. Aguarde a sincronização do Gradle.
5. Ligue um telemóvel Android com depuração USB ou use um emulador.
6. Para gerar um APK de teste: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. O Android Studio apresentará o caminho do APK gerado.

Requisitos indicativos: Android Studio recente, JDK 17 e ligação à internet na primeira sincronização para descarregar dependências.

## Nota
Este pacote é o código-fonte inicial do projecto, não um APK pronto a instalar. A compilação e os testes num dispositivo Android ainda são necessários.
